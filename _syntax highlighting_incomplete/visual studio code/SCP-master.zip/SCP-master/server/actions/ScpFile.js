"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class SCP_File {
}
exports.SCP_File = SCP_File;
//# sourceMappingURL=ScpFile.js.map