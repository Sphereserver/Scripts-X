"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class File {
}
exports.File = File;
//# sourceMappingURL=SCP_File.js.map