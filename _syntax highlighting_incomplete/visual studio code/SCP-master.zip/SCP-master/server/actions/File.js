"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class File {
}
exports.File = File;
//# sourceMappingURL=File.js.map