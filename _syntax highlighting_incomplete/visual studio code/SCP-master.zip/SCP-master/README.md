Syntax highlighting for UO Sphere Scripts.
This extension was made based on https://github.com/Armitxes/VSCode_SQF .

*After installation is necessary to switch to [SCP] Light Theme*
